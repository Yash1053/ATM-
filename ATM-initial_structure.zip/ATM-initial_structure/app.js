var newATM,
ATM = require('./src/atm.js');

//NODE ATM//
//STARTER FILE//

//START PROGRAM//
newATM = new ATM();
newATM.on();


